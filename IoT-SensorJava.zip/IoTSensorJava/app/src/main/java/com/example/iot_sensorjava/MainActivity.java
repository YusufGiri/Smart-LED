package com.example.iot_sensorjava;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    ToggleButton buttonRelay;


    TextView ldr;
    TextView statusPir;
    TextView statusSystem;

    String valueLdr;
    String valuePir;
    String valueRelay;
    String valueSystem;

    DatabaseReference dref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonRelay = (ToggleButton) findViewById(R.id.toggleButton);


        statusPir = (TextView) findViewById(R.id.txtPIR);
        statusSystem = (TextView) findViewById(R.id.txtSystem);
        ldr = (TextView) findViewById(R.id.txtCahaya);



        dref = FirebaseDatabase.getInstance().getReference();
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                valuePir = dataSnapshot.child("ESP32/pir").getValue().toString();
                if(valuePir.equals("0"))
                    statusPir.setText("No Motion");
                else
                    statusPir.setText("Motion Detect");

                valueSystem = dataSnapshot.child("ESP32/RFID").getValue().toString();
                if(valueSystem.equals("0"))
                    statusSystem.setText("System OFF");
                else
                    statusSystem.setText("System ON");

                valueLdr = dataSnapshot.child("ESP32/cahaya").getValue().toString();
                ldr.setText(valueLdr);

                valueRelay = dataSnapshot.child("ESP32/relay").getValue().toString();
                if(valueRelay.equals("0"))
                    buttonRelay.setChecked(false);
                else
                    buttonRelay.setChecked(true);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        buttonRelay.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    DatabaseReference lampu1Ref = FirebaseDatabase.getInstance().getReference("ESP32/relay");
                    lampu1Ref.setValue(1);
                }
                else
                {
                    DatabaseReference lampu1Ref = FirebaseDatabase.getInstance().getReference("ESP32/relay");
                    lampu1Ref.setValue(0);
                }
            }
        });

    }
}